# Space Horror
"Space Horror" is a dark colorful theme optimized for the pager with a space ambience and many unique backgrounds and creatures.  The theme is tested on 1.1.0 and originally built from "Zombie UFO".  I hope you have as much fun using my theme as I did creating it.


![Space Horror Payloads Dashboard](../images/Space_Horror_payloads.png)

![Space Horror Payloads Dashboard](../images/Space_Horror_payloads-dash.png)

![Space Horror Payloads Dashboard](../images/Space_Horror_launch-payload.png)

![Space Horror Payloads Dashboard](../images/Space_Horror_recon.png)

![Space Horror Payloads Dashboard](../images/Space_Horror_unlock.png)

![Space Horror Payloads Dashboard](../images/Space_Horror_keyboard.png)


During testing with other themes, the pager would run very warm and possibly overheat over a long period of time.  "Space Horror" is optimized to not overheat the pager while keeping a nice color contrast and full graphics.  It has been tested for days running payloads at 50% brightness (in moderate temperature environments) without any issue.  


# Space Horror Theme Screenshots
![Space Horror Theme Screenshots](../images/Space_Horror_full.jpg)


Thanks again Zombie Joe!
